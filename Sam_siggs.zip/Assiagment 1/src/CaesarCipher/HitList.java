/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CaesarCipher;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Neticius
 */
public class HitList implements Encryptable {

    List<String> targets = new ArrayList<>();
    boolean currentlyEncrypted;
    char currentKey;
    
    public HitList() {
       System.out.println("ENTER VICTIMS");
       
       Scanner enter = new Scanner(System.in);
       
       
       
       do {
           String k = enter.nextLine();
           if (k.equals("QUIT")) {
               break;
           }else {
               targets.add(k); 
           }
       } while(true);
       encrypt('C');
    }
    
    @Override
    public void encrypt(char key) {
//        int currentKey = (int)key - 65;
//        for (int i = 0; i < targets.size(); i++) {
//            char[] word = {};
//            for (int j = 0; j < targets.get(i).length(); j++) {
//                char Char = targets.get(i).charAt(j);
//                System.out.println(Char);
//                Char = (char) ((int)Char + currentKey);
//                word[j] = Char;
//            }
//            
//        }
        int e = (int)key;
        currentlyEncrypted = true;
    }

    @Override
    public void decrypt(char[] key) {
        int currentKey = -((int)key[0] - 65);
        currentlyEncrypted = false;
    }

    @Override
    public boolean isEncrypted() {
        return currentlyEncrypted;
    }
   
   public void addVictim(String victim) {
       targets.add(victim);
   }
   
   public String toString() {
       String output = "";
//       for (int i = 0; i < targets.size(); i++) {
//           System.out.println(targets.get(i));
//       }
       System.out.println(output.join("\n", targets));
       return output.join("\n", targets);
   }
   
   public static void main(String[] args) {
       HitList hit = new HitList();
       
   }
}
